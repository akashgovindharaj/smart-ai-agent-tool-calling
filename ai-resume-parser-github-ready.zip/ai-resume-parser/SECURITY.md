# Security Policy

## Reporting a vulnerability

Please do not publish API keys, resumes, or other personal information in an issue. For a private project, contact the repository owner through their GitHub profile to report a suspected vulnerability.

## Data and secret handling

- Store `OPENAI_API_KEY` in a local `.env` file or a secret manager; never commit secrets.
- Treat resumes as sensitive personal data. Use synthetic or explicitly consented sample resumes in public demos and tests.
- Do not log full resume text or API credentials.
- The parser sends extracted resume text to the configured OpenAI API. Do not use it with sensitive documents unless you have reviewed the provider's applicable terms and privacy requirements.
- Uploaded files should be stored only as long as necessary and deleted after processing by any future web application.

## Current limitations

- OCR for scanned PDFs is not implemented.
- File size is limited to 10 MiB, but this is not a complete malware or document-sandboxing defense.
- The project does not independently verify resume claims.
