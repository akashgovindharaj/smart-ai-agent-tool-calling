# AI-Powered Resume Parser

A Python portfolio project that extracts structured candidate information from PDF, DOCX, TXT, and Markdown resumes using the OpenAI API and Pydantic validation.

> **Status:** Source-level project with mocked unit tests. A live OpenAI request is not required for unit tests. Model extraction quality depends on the input, model, and API configuration; the application does not verify resume claims.

## Features

- Extract text from PDF, DOCX, TXT, and Markdown files.
- Parse contact details, skills, employment, education, projects, certifications, and experience estimates.
- Validate structured output using Pydantic and OpenAI Structured Outputs.
- Command-line interface and importable Python functions.
- Explicit handling for model refusals, empty parsed responses, missing choices, and OpenAI API errors.
- Basic file validation and a 10 MiB input-file limit.
- Unit tests that use a mocked client and do not call the OpenAI API.
- GitHub Actions test workflow for Python 3.11, 3.12, and 3.13.

## Requirements

- Python 3.11 or newer
- An OpenAI API key for live parsing

## Setup

### 1. Clone the repository

```bash
git clone https://github.com/akashgovindharaj/ai-resume-parser.git
cd ai-resume-parser
```

The clone command will work after this repository has been created and published at that address. Until then, use the downloaded ZIP or your local project folder.

### 2. Create and activate a virtual environment

```bash
python -m venv .venv
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### 4. Configure the API key

Copy `.env.example` to `.env`, then replace the placeholder with your own key:

macOS/Linux:

```bash
cp .env.example .env
```

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Never commit `.env` or paste your API key into source code, screenshots, issues, or public chat.

## Run the parser

Parse the included synthetic sample and write JSON to `output/`:

```bash
python -m resume_parser.cli samples/sample_resume.txt -o output/parsed_resume.json
```

Print JSON to the terminal instead:

```bash
python -m resume_parser.cli samples/sample_resume.txt
```

Supported extensions: `.pdf`, `.docx`, `.txt`, `.md`. Scanned PDFs that contain only images require OCR, which is not currently implemented. Input files larger than 10 MiB are rejected.

## Python API

```python
from resume_parser import parse_resume_file

resume = parse_resume_file("samples/sample_resume.txt")
print(resume.full_name)
print(resume.skills)
print(resume.model_dump_json(indent=2))
```

The API uses `OPENAI_MODEL` when set, otherwise it defaults to `gpt-4o-mini`. The model must be available to your API account and support the Structured Outputs interface used by the project. An illustrative synthetic output is available in [`samples/sample_output.json`](samples/sample_output.json); it is documentation data, not a captured live API response.

## Run tests

```bash
python -m pytest -q
```

The unit tests use a fake OpenAI client and should not need a real API key or make network calls. GitHub Actions runs the same tests on Python 3.11, 3.12, and 3.13. Do not claim the tests pass until they have completed successfully in your environment or CI run.

## Architecture

```text
Input file
   |
   v
resume_parser/extract.py  -> Extract plain text from supported formats
   |
   v
resume_parser/parser.py   -> Call OpenAI Structured Outputs; handle refusals/errors
   |
   v
resume_parser/schema.py   -> Validate Resume, Experience, Education, and Project data
   |
   v
resume_parser/cli.py      -> Print JSON or save JSON to a requested output path
```

- `resume_parser/extract.py`: file validation, file-size limit, and text extraction.
- `resume_parser/parser.py`: system instructions, OpenAI call, and response/error handling.
- `resume_parser/schema.py`: Pydantic models for structured resume fields.
- `resume_parser/cli.py`: command-line entry point.
- `tests/test_parser.py`: unit tests with a mocked API client.
- `samples/sample_resume.txt`: synthetic demo input.

## Security and privacy

Resume files can contain personal information. Extracted text is sent to the configured OpenAI API for live parsing. Use synthetic or consented data in demos, avoid logging full resume content, keep credentials in `.env`, and review the API provider's terms before processing sensitive data. See [SECURITY.md](SECURITY.md).

The 10 MiB limit is a basic safeguard, not a complete file-scanning or sandboxing solution. The project does not verify employment, education, or certification claims. Scanned-PDF OCR, web uploads, authentication, persistent storage, and job-description matching are not implemented in this version.

## Current scope and next steps

Implemented: document text extraction, structured LLM parsing, Pydantic validation, CLI, basic input checks, mocked unit tests, and CI configuration.

Not implemented: OCR, a web interface or REST API, job-description matching, a labelled evaluation dataset, database persistence, and agentic tool orchestration.

## License

No license file is included. Before inviting reuse or contributions, choose and add a license appropriate for your intended distribution. Without a license, do not assume others have permission to reuse, modify, or redistribute this code.
