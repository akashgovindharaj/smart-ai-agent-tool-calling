"""Pydantic schemas used to validate structured resume extraction."""
from typing import Optional

from pydantic import BaseModel, Field


class Education(BaseModel):
    institution: str
    degree: Optional[str] = Field(None, description="e.g. BSc, MSc, PhD")
    field_of_study: Optional[str] = None
    start_year: Optional[int] = None
    end_year: Optional[int] = Field(None, description="Null if ongoing")
    grade: Optional[str] = Field(
        None, description="Explicitly stated CGPA, GPA, or percentage; preserve its scale"
    )


class Experience(BaseModel):
    company: str
    title: str
    start_date: Optional[str] = Field(None, description="YYYY-MM or YYYY")
    end_date: Optional[str] = Field(None, description="YYYY-MM, YYYY, or 'Present'")
    highlights: list[str] = Field(description="Key responsibilities or achievements as short bullets")


class Project(BaseModel):
    name: str
    description: Optional[str] = None
    technologies: list[str] = Field(default_factory=list)
    start_date: Optional[str] = Field(None, description="YYYY-MM or YYYY, if stated")
    end_date: Optional[str] = Field(None, description="YYYY-MM or YYYY, if stated")
    highlights: list[str] = Field(default_factory=list)


class Resume(BaseModel):
    full_name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None
    links: list[str] = Field(description="LinkedIn, GitHub, portfolio URLs")
    summary: Optional[str] = None
    skills: list[str]
    experience: list[Experience]
    education: list[Education]
    projects: list[Project] = Field(default_factory=list)
    certifications: list[str]
    total_years_experience: Optional[float] = Field(
        None, description="Estimated total professional years; leave null if it cannot be inferred reliably"
    )
