"""Usage: python -m resume_parser.cli resume.pdf [-o output/resume.json]"""
import argparse
from pathlib import Path

from .parser import parse_resume_file


def main() -> None:
    ap = argparse.ArgumentParser(description="Parse a resume into JSON.")
    ap.add_argument("file", help="Path to .pdf, .docx, .txt")
    ap.add_argument("-o", "--output", help="Write JSON to this path")
    args = ap.parse_args()

    resume = parse_resume_file(args.file)
    js = resume.model_dump_json(indent=2)
    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(js, encoding="utf-8")
        print(f"Saved to {out}")
    else:
        print(js)


if __name__ == "__main__":
    main()
