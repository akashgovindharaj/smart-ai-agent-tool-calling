"""Turn PDF, DOCX, TXT, and Markdown files into plain text."""
from pathlib import Path

MAX_FILE_BYTES = 10 * 1024 * 1024


def extract_text(path: str | Path) -> str:
    """Extract text from a supported resume file, with a basic size limit."""
    path = Path(path)
    if not path.exists() or not path.is_file():
        raise ValueError("Resume path does not exist or is not a regular file.")
    if path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError("Resume file exceeds the 10 MiB size limit.")

    suffix = path.suffix.lower()
    if suffix == ".pdf":
        from pypdf import PdfReader

        reader = PdfReader(str(path))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
    elif suffix == ".docx":
        from docx import Document

        text = "\n".join(p.text for p in Document(str(path)).paragraphs)
    elif suffix in {".txt", ".md"}:
        text = path.read_text(encoding="utf-8")
    else:
        raise ValueError(f"Unsupported file type: {suffix or '(no extension)'}")

    text = text.strip()
    if not text:
        raise ValueError(
            "No text found. Scanned PDFs need OCR, which is not currently implemented."
        )
    return text
