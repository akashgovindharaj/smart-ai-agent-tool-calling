from pathlib import Path
from types import SimpleNamespace

import pytest

from resume_parser import Resume, parse_resume_text
from resume_parser.extract import MAX_FILE_BYTES, extract_text

SAMPLE = Path(__file__).parent.parent / "samples" / "sample_resume.txt"


class FakeClient:
    """Mimics client.chat.completions.parse without making a network request."""

    def __init__(self, parsed=None, refusal=None, error=None, choices=True):
        self.error = error
        message = SimpleNamespace(parsed=parsed, refusal=refusal)
        result = SimpleNamespace(choices=[SimpleNamespace(message=message)] if choices else [])

        def parse(**kwargs):
            if self.error:
                raise self.error
            return result

        self.chat = SimpleNamespace(completions=SimpleNamespace(parse=parse))


def make_resume():
    return Resume(
        full_name="Jane Doe", links=[], skills=["Python"], experience=[],
        education=[], projects=[], certifications=[]
    )


def test_extract_txt():
    assert "Jane Doe" in extract_text(SAMPLE)


def test_extract_unsupported(tmp_path):
    f = tmp_path / "x.png"
    f.write_bytes(b"")
    with pytest.raises(ValueError, match="Unsupported file type"):
        extract_text(f)


def test_extract_missing_file():
    with pytest.raises(ValueError, match="does not exist"):
        extract_text("missing-resume.txt")


def test_extract_file_size_limit(tmp_path):
    f = tmp_path / "large.txt"
    f.write_bytes(b"x" * (MAX_FILE_BYTES + 1))
    with pytest.raises(ValueError, match="10 MiB"):
        extract_text(f)


def test_parse_returns_resume():
    result = parse_resume_text("resume text", client=FakeClient(parsed=make_resume()))
    assert result.full_name == "Jane Doe"
    assert result.skills == ["Python"]


def test_empty_input_rejected():
    with pytest.raises(ValueError, match="must not be empty"):
        parse_resume_text("  ", client=FakeClient(parsed=make_resume()))


def test_refusal_raises():
    with pytest.raises(RuntimeError, match="refused"):
        parse_resume_text("resume text", client=FakeClient(refusal="not allowed"))


def test_missing_parsed_response_raises():
    with pytest.raises(RuntimeError, match="no parsed resume"):
        parse_resume_text("resume text", client=FakeClient(parsed=None))


def test_empty_choices_raises():
    with pytest.raises(RuntimeError, match="no choices"):
        parse_resume_text("resume text", client=FakeClient(choices=False))


def test_api_error_is_wrapped():
    with pytest.raises(RuntimeError, match="OpenAI request failed"):
        parse_resume_text("resume text", client=FakeClient(error=TimeoutError("simulated")))


def test_schema_preserves_project_and_grade_fields():
    resume = Resume(
        full_name="Jane Doe", links=[], skills=[], experience=[],
        education=[{"institution": "Example University", "grade": "8.2/10"}],
        projects=[{"name": "Expense Tracker", "technologies": ["Python"]}],
        certifications=[]
    )
    assert resume.education[0].grade == "8.2/10"
    assert resume.projects[0].name == "Expense Tracker"
